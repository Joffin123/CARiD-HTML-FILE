jQuery(document).ready(function ($) {
    /*
     * Menu- Start
     */
	 $('.w-menu ul li.mega-menus ul.sub-menu li:has(ul)').prepend().addClass('megamenu-li');
	 
	 
	 $('.w-menu ul li.mega-menus ul.sub-menu li:not(ul)').addClass('megamenu-with-out-sub');
	 $('.megamenu-li').removeClass('megamenu-with-out-sub');
	 $('.sub-menu ul li').removeClass('megamenu-with-out-sub');
	 
	 
	 //$('.w-menu ul li.mega-menus .megamenu-li:not(ul)').prepend().addClass('KKK');
	 $('.w-menu ul li:has(ul)').append('<span class="arrow-plus" />');
	 $('.w-menu ul li:has(ul)').prepend().addClass('have-sub-menu');

    $(".w-menu ul li").mouseover(function () {
        if ($(this).children('ul').length == 1) {
            var parent = $(this);
            var child_menu = $(this).children('ul');
            if ($(parent).offset().left + $(parent).width() + $(child_menu).width() > $(window).width()) {
                $(child_menu).addClass('right');
            } else {
                //$(child_menu).addClass('left');
            }
        }
    });

    $(".arrow-plus").click(function () {

        $(this).parent('li').find('ul:first').toggleClass('w-submenu');

        $(this).parent('li').siblings().find('ul').removeClass('w-submenu');

        $(this).toggleClass('arrow-minimize');

        $(this).parent('li').siblings().find('span.arrow-plus').removeClass('arrow-minimize');

    });

    $('.w-menu ul li').click(function () {

        $(this).addClass('active').siblings().removeClass('active');

        $(this).addClass('active').siblings().find('li.active').removeClass('active');

    });

    $('.mobile-menu-icon').click(function (e) {

        e.preventDefault();

        $(".mobile-menu-icon").toggleClass('icon-open');

        $(".mobile-menu").toggleClass('menu-open');

        $('.w-menu ul').removeClass('w-submenu');

        $('.arrow-plus').removeClass('arrow-minimize');

    });

    /*
     * Menu-End
     * Slider-Start
     */
   



$.fn.bsTouchSlider = function (options) {

        var carousel = $(".carousel");

        return this.each(function ( ) {



            function doAnimations(elems) {

                //Cache the animationend event in a variable

                var animEndEv = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';

                elems.each(function ( ) {

                    var $this = $(this),
                            $animationType = $this.data('animation');

                    $this.addClass($animationType).one(animEndEv, function ( ) {

                        $this.removeClass($animationType);

                    });

                });

            }



            //Variables on page load

            var $firstAnimatingElems = carousel.find('.carousel-item:first').find("[data-animation ^= 'animated']");

            //Initialize carousel

            carousel.carousel( );

            //Animate captions in first slide on page load

            doAnimations($firstAnimatingElems);

            //Other slides to be animated on carousel slide event

            carousel.on('slide.bs.carousel', function (e) {

                var $animatingElems = $(e.relatedTarget).find("[data-animation ^= 'animated']");

                doAnimations($animatingElems);

            });

            //swipe initial 

            $(".carousel .carousel-inner").swipe({

                swipeLeft: function (event, direction, distance, duration, fingerCount) {

                    this.parent( ).carousel('next');

                },

                swipeRight: function ( ) {

                    this.parent( ).carousel('prev');

                },

                threshold: 0

            });



        });

    };
    $('#weberge-slider').bsTouchSlider();


}(jQuery));
/*
 * Jquery Ends here
 *
 */


var options = {
    'myslider-inner': {
        container: '',
        items: 2,
        startIndex: 0,
        slideBy: 1, // all display item 'slideBy:page'
        loop: false,
        rewind: false,
        axis: 'horizontal', // horizontal or 'vertical'
        mouseDrag: true,

        fixedWidth: '', // each slider width 'fixedWidth: 300'
        edgePadding: '', // space left and right
        autoHeight: '',
        arrowKeys: true,
        lazyload: true,
        gutter: 10, // space between slider
        controlsText: ['', ''],
        //autoplay: true,
        //autoplayHoverPause: true,
        //autoplayTimeout: 1500,
        //autoplayText: [ '▶','❚❚'],
        //autoplayButtonOutput: true,

        //IF USE FADE ANIMATION PLEASE ACTIVE mode:gallery AND loop:false

        //mode:'gallery',
        //animateIn: 'weg-fadeIn',
        //animateOut: 'weg-fadeOut',

    }
};




var speed = 400;
var initFns = {};
var sliders = new Object();
for (var i in options) {
    var item = options[i];
    item.container = '#' + i;
    if (!item.speed) {
        item.speed = speed;
    }

    if (document.querySelector(item.container)) {
        sliders[i] = weg(options[i]);
        // test responsive pages
    } else if (i.indexOf('responsive') >= 0) {
        if (initFns[i]) {
            initFns[i]();
        }
    }
}


//Gallery Section Start
$(document).ready(function(){

    $(".filter-button").click(function(){
        var value = $(this).attr('data-filter');
        
        if(value == "all")
        {
            //$('.filter').removeClass('hidden');
            $('.filter').show('1000');
        }
        else
        {
//            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
//            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
            $(".filter").not('.'+value).hide('3000');
            $('.filter').filter('.'+value).show('3000');
            
        }
    });

});
//Gallery Section End



jQuery(function($) {
    $(window).on("scroll", function () {
        if ($(this).scrollTop() > 50) {
            $("#header").addClass("stickyHeader");
        }
        else {
            $("#header").removeClass("stickyHeader");
        }
    })
});



