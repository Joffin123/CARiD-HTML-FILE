var options = {
  'news-events-slider': {
    container: '',
	axis: 'horizontal',//vertical, horizontal
    items: 3,
    speed: 300,
    autoplay: true,
    autoplayHoverPause: true,
    autoplayTimeout: 1500,
	loop: true,
	//animateIn: 'tns-fadeIn',
   //animateOut: 'tns-fadeOut',
	//mode:'gallery',
	
	//nav: false,
	//navAsThumbnails: false,
	fixedWidth: '', // each slider width 'fixedWidth: 300'
	edgePadding:'', // space left and right
	autoHeight: '',
	arrowKeys: true,
	lazyload: true,
	gutter: 50, // space between slider
	controlsText: ['', ''],
    autoplayHoverPause: true,
	
    autoplayText: ['', ''],
	//autoplayText: ['&#9658;', '❚❚'],
	 mouseDrag: true,
    // autoplayButtonOutput: false,
    responsive: {
      991: {
        items: 2,
      },
      768: {
        items: 1,
      },
    480: {
        items: 1,
      },
    0: {
        items: 1,
      }
  },
  
  },'recent-videos-slider': {
    container: '',
	axis: 'horizontal',//vertical, horizontal
    items: 3,
    speed: 300,
    autoplay: true,
    autoplayHoverPause: true,
    autoplayTimeout: 1500,
	loop: true,
	//animateIn: 'tns-fadeIn',
   //animateOut: 'tns-fadeOut',
	//mode:'gallery',
	
	//nav: false,
	//navAsThumbnails: false,
	fixedWidth: '', // each slider width 'fixedWidth: 300'
	edgePadding:'', // space left and right
	autoHeight: '',
	arrowKeys: true,
	lazyload: true,
	gutter: 40, // space between slider
	controlsText: ['', ''],
    autoplayHoverPause: true,
	
    autoplayText: ['', ''],
	//autoplayText: ['&#9658;', '❚❚'],
	 mouseDrag: true,
    // autoplayButtonOutput: false,
    responsive: {
      991: {
        items: 2,
      },
      768: {
        items: 1,
      },
    480: {
        items: 1,
      },
    0: {
        items: 1,
      }
  },
  
  },
  'hotel2': {
    container: '',
	axis: 'horizontal',//vertical, horizontal
    items: 3,
    speed: 300,
    autoplay: true,
    autoplayHoverPause: true,
    autoplayTimeout: 1500,
	loop: true,
	//animateIn: 'tns-fadeIn',
   //animateOut: 'tns-fadeOut',
	//mode:'gallery',
	
	//nav: false,
	//navAsThumbnails: false,
	fixedWidth: '', // each slider width 'fixedWidth: 300'
	edgePadding:'', // space left and right
	autoHeight: '',
	arrowKeys: true,
	lazyload: true,
	gutter: 32, // space between slider
	controlsText: ['', ''],
    autoplayHoverPause: true,
	
    autoplayText: ['', ''],
	//autoplayText: ['&#9658;', '❚❚'],
	 mouseDrag: true,
    // autoplayButtonOutput: false,
    responsive: {
      991: {
        items: 1,
      },
      768: {
        items: 1,
      },
    480: {
        items: 1,
      },
    0: {
        items: 1,
      }
  },
  
  },'hotel3': {
    container: '',
	axis: 'horizontal',//vertical, horizontal
    items: 3,
    speed: 300,
    autoplay: true,
    autoplayHoverPause: true,
    autoplayTimeout: 1500,
	loop: true,
	//animateIn: 'tns-fadeIn',
   //animateOut: 'tns-fadeOut',
	//mode:'gallery',
	
	//nav: false,
	//navAsThumbnails: false,
	fixedWidth: '', // each slider width 'fixedWidth: 300'
	edgePadding:'', // space left and right
	autoHeight: '',
	arrowKeys: true,
	lazyload: true,
	gutter: 32, // space between slider
	controlsText: ['', ''],
    autoplayHoverPause: true,
	
    autoplayText: ['', ''],
	//autoplayText: ['&#9658;', '❚❚'],
	 mouseDrag: true,
    // autoplayButtonOutput: false,
    responsive: {
      991: {
        items: 1,
      },
      768: {
        items: 1,
      },
    480: {
        items: 1,
      },
    0: {
        items: 1,
      }
  },
  
  },'attraction-slider': {
    container: '',
	axis: 'horizontal',//vertical, horizontal
    items: 3,
    speed: 300,
    autoplay: true,
    autoplayHoverPause: true,
    autoplayTimeout: 1500,
	loop: true,
	//animateIn: 'tns-fadeIn',
   //animateOut: 'tns-fadeOut',
	//mode:'gallery',
	
	//nav: false,
	//navAsThumbnails: false,
	fixedWidth: '', // each slider width 'fixedWidth: 300'
	edgePadding:'', // space left and right
	autoHeight: '',
	arrowKeys: true,
	lazyload: true,
	gutter: 32, // space between slider
	controlsText: ['', ''],
    autoplayHoverPause: true,
	
    autoplayText: ['', ''],
	//autoplayText: ['&#9658;', '❚❚'],
	 mouseDrag: true,
    // autoplayButtonOutput: false,
    responsive: {
      991: {
        items: 3,
      },
      768: {
        items: 1,
      },
    480: {
        items: 1,
      },
    0: {
        items: 1,
      }
  },
  
  }
};


      
var isTestPage,
	doc = document;
      initFns = {},
      sliders = new Object(),
      speed = 400;
for (var i in options) {
  var item = options[i];
  item.container = '#' + i;
  if (!item.speed) { item.speed = speed; }
  
  if (doc.querySelector(item.container)) {
    sliders[i] = tns(options[i]);
  // test responsive pages
  } else if (i.indexOf('responsive') >= 0) {
    if (isTestPage && initFns[i]) { initFns[i](); }
  }
}


